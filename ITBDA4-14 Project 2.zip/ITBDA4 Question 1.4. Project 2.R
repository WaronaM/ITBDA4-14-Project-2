# Question 1
# 1.4 Hadoop MapReduce Configuration Settings

# Select any text document from the docs folder
selected_file <- file.choose()

# Automatically identify the input folder
DOCS_DIR <- dirname(selected_file)

# Output settings
OUTPUT_DIR <- file.path(DOCS_DIR, "mapreduce_output")
OUTPUT_FILE <- file.path(OUTPUT_DIR, "results.csv")

# Enter the search keyword dynamically
KEYWORD <- trimws(KEYWORD)

if (KEYWORD == "") {
  stop("Please enter a keyword when prompted.")
}

print(KEYWORD)

# Search settings
CASE_INSENSITIVE <- TRUE
FILE_PATTERN <- "\\.txt$"

# Find all text documents in the selected folder
input_files <- list.files(
  path = DOCS_DIR,
  pattern = FILE_PATTERN,
  full.names = TRUE
)

# Check whether documents exist
if (length(input_files) == 0) {
  stop("No text documents found in the selected folder.")
}

# Check whether a keyword was entered
if (trimws(KEYWORD) == "") {
  stop("Please enter a search keyword.")
}

# Create the output folder
if (!dir.exists(OUTPUT_DIR)) {
  dir.create(OUTPUT_DIR)
}

# Display the configuration settings
cat("Input folder:", DOCS_DIR, "\n")
cat("Number of documents:", length(input_files), "\n")
cat("Keyword:", KEYWORD, "\n")
cat("Output file:", OUTPUT_FILE, "\n")


