# Question4 
# Question 4.1: Extract web data
library(rvest)

url <- "https://www.r-bloggers.com/"
page <- read_html(url)

# Find article links
articles <- html_elements(page, ".loop-title a")

data <- data.frame(
  title = html_text2(articles),
  link = html_attr(articles, "href"),
  stringsAsFactors = FALSE
)

# Remove empty records
data <- data[!is.na(data$title) & data$title != "" &
               !is.na(data$link), ]

# Add numeric column
data$link_length <- nchar(data$link)

# Check and save
print(head(data))
cat("Number of records:", nrow(data), "\n")

write.csv(data, "raw_web_data.csv", row.names = FALSE)


# Question 4.2: Data Cleaning

# Load raw data
df <- read.csv("raw_web_data.csv", stringsAsFactors = FALSE)

# Remove extra spaces
df$title <- trimws(df$title)
df$link <- trimws(df$link)

# Remove missing or empty values
df <- df[!is.na(df$title) & df$title != "" &
           !is.na(df$link) & df$link != "", ]

# Remove duplicate links
df <- df[!duplicated(df$link), ]

# Convert link_length to numeric
df$link_length <- as.numeric(df$link_length)

# Remove rows with missing numeric values
df <- df[!is.na(df$link_length), ]

# Save cleaned data
write.csv(df, "cleaned_web_data.csv", row.names = FALSE)

# Check the results
head(df)
cat("Cleaned records:", nrow(df), "\n")

# Question 4.3
install.packages(c("DBI", "RPostgres"))

library(DBI)

library(RPostgres)

con <- dbConnect(
  
  RPostgres::Postgres(),
  
  dbname = "etl_project",
  
  host = "localhost",
  
  port = 5432,
  
  user = "postgres",
  
  password = "?03Wethu"
  
)

cleaned_data <- read.csv(
  
  "C:/Users/Warona/OneDrive/Documents/Initial Summative/cleaned_hacker_news_data.csv",
  
  stringsAsFactors = FALSE
  
)

dbWriteTable(
  
  con,
  
  "hacker_news",
  
  cleaned_data,
  
  overwrite = TRUE
  
)

dbGetQuery(
  
  con,
  
  "SELECT COUNT(*) AS total_records FROM hacker_news;"
  
)

top_posts <- dbGetQuery(
  
  con,
  
  "

  SELECT title, points, comments

  FROM hacker_news

  ORDER BY points DESC

  LIMIT 10;

  "
  
)

print(top_posts)

engagement <- dbGetQuery(
  
  con,
  
  "

  SELECT

      ROUND(AVG(points), 2) AS average_points,

      ROUND(AVG(comments), 2) AS average_comments,

      MAX(points) AS highest_points,

      MAX(comments) AS highest_comments

  FROM hacker_news;

  "
  
)

print(engagement)



# SELECT
# ROUND(AVG(points), 2) AS average_points,
# ROUND(AVG(comments), 2) AS average_comments,
# MAX(points) AS highest_points,
# MAX(comments) AS highest_comments
# FROM hacker_news;

# SELECT title, points, comments
# FROM hacker_news
# ORDER BY points DESC
# LIMIT 10;
