# Question 1
#1.3.

# 1. Mapper
mapper <- function(doc_path, keyword) {
  lines <- readLines(doc_path, warn = FALSE)
  doc_name <- basename(doc_path)
  results <- list()
  
  for (i in seq_along(lines)) {
    positions <- gregexpr(keyword, lines[i], ignore.case = TRUE)[[1]]
    
    if (positions[1] != -1) {
      results[[length(results) + 1]] <- list(
        key = doc_name,
        value = list(row = i, cols = as.integer(positions))
      )
    }
  }
  
  return(results)
}

# 2. Shuffler
shuffler <- function(all_kv_pairs) {
  grouped <- list()
  
  for (pair in all_kv_pairs) {
    key <- pair$key
    
    if (is.null(grouped[[key]])) {
      grouped[[key]] <- list()
    }
    
    grouped[[key]][[length(grouped[[key]]) + 1]] <- pair$value
  }
  
  return(grouped)
}

# 3. Reducer
reducer <- function(doc_name, values) {
  results <- data.frame(
    Document = character(),
    Row = integer(),
    Columns = character()
  )
  
  for (v in values) {
    results <- rbind(results, data.frame(
      Document = doc_name,
      Row = v$row,
      Columns = paste(v$cols, collapse = ", ")
    ))
  }
  
  return(results)
}

# 4. Select a document
doc_path <- file.choose()

# 5. Enter the keyword
keyword <- readline("Enter the keyword to search: ")

# 6. Run MapReduce
mapped <- mapper(doc_path, keyword)
shuffled <- shuffler(mapped)

if (length(shuffled) == 0) {
  cat("No matches found.\n")
} else {
  final_result <- do.call(rbind, lapply(names(shuffled), function(doc) {
    reducer(doc, shuffled[[doc]])
  }))
  
  print(final_result)
}
