# Question 1
# 1.2 Mapper function
mapper <- function(doc_path, keyword) {
  
  lines <- readLines(doc_path, warn = FALSE)
  doc_name <- basename(doc_path)
  results <- list()
  
  for (i in seq_along(lines)) {
    positions <- gregexpr(keyword, lines[i], ignore.case = TRUE)[[1]]
    
    if (positions[1] != -1) {
      results[[length(results) + 1]] <- list(
        key = doc_name,
        row = i,
        columns = as.integer(positions)
      )
    }
  }
  
  return(results)
}

# Select a text document
doc_path <- file.choose()

# Enter the keyword
keyword <- readline("Enter the keyword to search: ")

# Run the Mapper
result <- mapper(doc_path, keyword)

# Display results
print(result)
