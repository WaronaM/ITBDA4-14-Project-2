# Question 3
# Question 3.1: Web Scraping

library(rvest)

# Website URL
url <- "https://en.wikipedia.org/wiki/Artificial_intelligence"

# Read the webpage
webpage <- read_html(url)

# Extract and clean paragraphs
paragraphs <- html_elements(webpage, "p") |>
  html_text2()

paragraphs <- paragraphs[nchar(trimws(paragraphs)) > 40]

# Create the data frame
article_df <- data.frame(
  source = url,
  paragraph_id = seq_along(paragraphs),
  text = paragraphs
)

# View the extracted data
head(article_df, 2)

# Save to CSV
write.csv(article_df, "article_text.csv", row.names = FALSE)



# Question 3.2: Text Preprocessing

library(tm)

# Create a text corpus
corpus <- Corpus(VectorSource(article_df$text))

# Clean the text
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, content_transformer(function(x)
  gsub("https?://\\S+|www\\.\\S+", "", x)))
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords, stopwords("english"))
corpus <- tm_map(corpus, stripWhitespace)

# Convert cleaned text to a data frame
cleaned_df <- data.frame(
  paragraph_id = article_df$paragraph_id,
  cleaned_text = sapply(corpus, as.character)
)

# View and save the results
head(cleaned_df, 2)
write.csv(cleaned_df, "article_text_cleaned.csv", row.names = FALSE)




# Question 3.3: TF-IDF Summarisation

library(tm)

# Create a document-term matrix from the cleaned corpus
dtm <- DocumentTermMatrix(corpus)
m <- as.matrix(dtm)

# Calculate TF-IDF scores
tfidf <- weightTfIdf(dtm)
scores <- rowSums(as.matrix(tfidf))

# Select the top 4 paragraphs
top4 <- order(scores, decreasing = TRUE)[1:min(4, length(scores))]
top4 <- sort(top4)

# Display the summary
cat("TF-IDF Summary\n")

for (i in top4) {
  cat("\nParagraph", i, ":\n")
  cat(article_df$text[i], "\n")
}

