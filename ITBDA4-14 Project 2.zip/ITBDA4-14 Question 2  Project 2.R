# Question 2
# Question 2.1: Load and Preprocess News Files

# Load required library
library(tm)

# Step 1: Find all news text files

# Step 1: Select a news text file
selected_file <- file.choose()

# Find the folder containing the selected file
DOCS_DIR <- dirname(selected_file)

# Find all news text files in that folder
files <- list.files(
  DOCS_DIR,
  pattern = "\\.txt$",
  full.names = TRUE
)

# Check that files were found
if (length(files) == 0) {
  stop("No news text files found in the selected folder.")
}

print(files)


# Step 2: Create a data frame
df <- data.frame(
  col_1 = basename(files),
  col_2 = sapply(files, function(f) {
    paste(readLines(f, warn = FALSE), collapse = " ")
  }),
  stringsAsFactors = FALSE
)

# Display the original data frame
head(df, 2)
cat("Rows:", nrow(df), "Columns:", ncol(df), "\n")

# Step 3: Create a text corpus
corpus <- VCorpus(VectorSource(df$col_2))

# Step 4: Preprocess the text
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords, stopwords("english"))
corpus <- tm_map(corpus, stripWhitespace)

# Step 5: Store the cleaned text in the data frame
df$col_2 <- sapply(corpus, as.character)

# Display the cleaned data
head(df, 2)
cat("Preprocessing completed.\n")

# Create the Document-Term Matrix
dtm <- DocumentTermMatrix(corpus, control = list(wordLengths = c(4, Inf)))

# Remove very rare words
dtm <- removeSparseTerms(dtm, 0.99)

# Remove documents with no words
row_totals <- apply(dtm, 1, sum)
dtm_clean <- dtm[row_totals > 0, ]

# Check the result
dim(dtm_clean)



# Question 2.2: Latent Dirichlet Allocation (LDA)

# Load required libraries
library(topicmodels)
library(tidytext)
library(dplyr)

# Set the number of topics and top words
set.seed(42)
n_topics <- 4
k_words <- 8

# Run LDA
lda_model <- LDA(dtm_clean, k = n_topics, control = list(seed = 42))

# Get word probabilities for each topic
topics <- tidy(lda_model, matrix = "beta")

# Display the top words for each topic
top_words <- topics %>%
  group_by(topic) %>%
  slice_max(beta, n = k_words) %>%
  arrange(topic, desc(beta))

print(top_words)

# Get document-topic distributions
doc_topics <- tidy(lda_model, matrix = "gamma")

print(doc_topics)


#Question 2.3.

# Get the top 8 words for each topic
library(tidytext)
library(dplyr)
library(ggplot2)

topics <- tidy(lda_model, matrix = "beta")

top_terms <- topics %>%
  group_by(topic) %>%
  slice_max(order_by = beta, n = 8) %>%
  ungroup()

# Display the selected words
print(top_terms)

# Visualisation 1: Bar Chart

library(ggplot2)
library(dplyr)

ggplot(top_terms, aes(x = reorder(term, beta), y = beta)) +
  geom_col(fill = "steelblue") +
  coord_flip() +
  facet_wrap(~ topic, scales = "free") +
  labs(
    title = "Top 8 Keywords per Topic",
    x = "Keywords",
    y = "Word Probability"
  ) +
  theme_minimal()

# Visualisation 2: Word Clouds

library(wordcloud)
library(RColorBrewer)
library(dplyr)

par(mfrow = c(2, 2), mar = c(1, 1, 3, 1))

for (t in 1:4) {
  words <- filter(top_terms, topic == t)
  
  wordcloud(
    words = words$term,
    freq = words$beta * 100,
    max.words = 8,
    scale = c(2, 0.6),
    colors = brewer.pal(8, "Set2"),
    random.order = FALSE
  )
  
  title(paste("Topic", t))
}
